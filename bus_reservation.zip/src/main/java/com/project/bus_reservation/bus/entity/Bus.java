package com.project.bus_reservation.bus.entity;

import com.google.cloud.firestore.annotation.DocumentId;
import com.google.cloud.spring.data.firestore.Document;
import com.project.bus_reservation.bus.enums.BusStatus;
import com.project.bus_reservation.bus.enums.BusType;
import com.project.bus_reservation.seats.entity.Seat;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.*;

import com.google.cloud.Timestamp;
import java.util.ArrayList;
import java.util.List;

@Document(collectionName = "buses")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Bus {
    @DocumentId
    private String id;

    @NotNull
    @Positive
    private Integer busNumber;

    @NotBlank
    private String busName;

    private BusType busType;

    @Min(18)
    private Integer totalSeats;

    private BusStatus status;

    private Timestamp createdAt = Timestamp.now();
    private Timestamp modifiedAt = Timestamp.now();

    private String operatorId;
    private String routeId;

    private List<Seat> seats = new ArrayList<>();
}